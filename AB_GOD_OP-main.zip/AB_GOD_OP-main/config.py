# Don't use quotes( " and ' )
#SCRIPT BY GODxBGMI
  
#Enter Your Bot Token here get it from @botfarher
BOT_TOKEN=("7353106103:AAEmWPOELbGBOlzJiKX-LUkS-WcHcqTYphc")

  #Enter Your telegram username here without @
OWNER_USERNAME=("GODxBGMI_OWNER")

  #Enter your admin id here Get it from @missRose_bot by typing /info
ADMIN_IDS=("1132426169")







  
